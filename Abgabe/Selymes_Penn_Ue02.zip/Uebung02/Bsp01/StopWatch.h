#ifndef STOPWATCH_H
#define STOPWATCH_H


namespace stw {
   void   Start ();
   double Stop  ();   // Returns seconds.
}


#endif   // STOPWATCH_H